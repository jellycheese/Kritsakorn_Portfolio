// /** @type {import('@sveltejs/kit').Handle} */
// export async function handle({ event, resolve }) {	
//     event.locals.user = await 
//     getUser(event.cookies.get('sessionid'));	
//     return resolve(event);}