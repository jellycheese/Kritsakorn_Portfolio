<style>
    body{
        margin-top: 100px;
    }
    .icon-square img {
      max-width: 50px;
      max-height: 50px;
    }
    .styled-link {
      color: rgb(230, 176, 176);
      text-decoration: none;
      font-weight: bold;
  }
   
  .styled-link:hover {
      color: rgb(230, 117, 117);
      text-decoration: none;
  }
   
  </style>
  <body>
    
  <div class="jumbotron text-center">
    <h1>Help center</h1>
    <p>How can we help you?</p>
  </div>
   
     <div class="container">
          <div class="row">
              <div class="col">
                  <div class="icon-square">
                      <img src="shopping-basket.png" alt="howtoshop">
                  </div>
                  <div>
                      <h3 class="fs-4">How to shop</h3>
                      <p>How to use OnceAgain?</p>
                      <a class="styled-link" href="/helpcenter/how-to-shop">How to shop</a>
                  </div>
              </div>
              <div class="col">
                  <div class="icon-square">
                      <img src="return.png" alt="return">
                  </div>
                  <div>
                      <h3 class="fs-4">Exchange&return</h3>
                      <p>How to exchange/return an item?</p>
                      <a class="styled-link" href="/helpcenter/exchange-return">Exchange/Return</a>
                  </div>
              </div>
              <div class="col">
                  <div class="icon-square">
                      <img src="pay.png" alt="pay">
                  </div>
                  <div>
                      <h3 class="fs-4">Payment</h3>
                      <p>What are the payment methods available?</p>
                      <a class="styled-link" href="/helpcenter/payment">Payment</a>
                  </div>
              </div>
          </div>
  </div>
  <br>
   
   
    <div class="h-100 p-5 bg-light border rounded-3">
        <h4>ต้องการความช่วยเหลือเพิ่มเติม</h4>
        <ul class="list-unstyled mt-3 mb-4">
          <li>โทร. 02-000-0000</li>
          <li>เวลาให้บริการ: ทุกวันจันทร์-เสาร์ เวลา 08.00น. ถึง 22.00น.</li>
        </ul>
   
   
    </div>
</body>
