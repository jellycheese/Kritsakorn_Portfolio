<style>
    body{
        margin-top: 100px;
        margin-left: 20px;
    }
    .section-heading {
        padding-bottom: 1.5rem;
        font-weight: bold;
        border-bottom: 1px solid #000;
    }
   
    .step-heading {
        font-size: 1.5rem;
        font-weight: bold;
        line-height: 1;
        margin-bottom: 1rem;
    }
   
    .step-description {
        font-size: 1rem;
        line-height: 1.6;
        list-style-type: disc;
        padding-left: 20px;
    }
    </style>

<body>
    
    <h3 class="section-heading">How to Shop with OnceAgain</h3>
 
<div class="container">
    <div class="row flex align-items-center g-5 py-5">
       
        <div>
            <h1 class="step-heading">Step 1: Browse or Search for Products</h1>
            <ul class="step-description">
                <li>You’ll typically see a home screen with various products.</li>
                <li>Or use the search bar at the top to type in keywords for the products you’re looking for.</li>
            </ul>
        </div>
 
        <div>
            <h1 class="step-heading">Step 2: Select a Product</h1>
            <ul class="step-description">
                <li>Once you find a product that interests you, check the price and available quantities.</li>
            </ul>
        </div>
 
        <div>
            <h1 class="step-heading">Step 3: Add to Cart</h1>
            <ul class="step-description">
                <li>Press +/- to increase or decrease the quantities you want.</li>
                <li>Click the “Add to Cart” button to add the item to your shopping cart.</li>
                <li>You can continue shopping and add more items if needed.</li>
            </ul>
        </div>
 
        <div>
            <h1 class="step-heading">Step 4: Checkout</h1>
            <ul class="step-description">
                <li>Go to cart at the top of the screen.</li>
                <li>Check the items in your cart to make sure everything is correct. You can adjust quantities or remove items if necessary.</li>
                <li>Once you’re ready to purchase, click the “Go to payment” button.</li>
            </ul>
        </div>
 
        <div>
            <h1 class="step-heading">Step 5: Place an Order</h1>
            <ul class="step-description">
                <li>Enter your shipping address.</li>
                <li>Check the order details.</li>
                <li>Choose your preferred payment method.</li>
                <li>Click the “ยืนยันการชำระเงิน” button to complete your order.</li>
            </ul>
        </div>
    </div>
</div>
 
<ul class="pager">
    <li class="previous"><a href="/helpcenter" class="btn" role="button">Back</a></li>
</ul>
</body>
