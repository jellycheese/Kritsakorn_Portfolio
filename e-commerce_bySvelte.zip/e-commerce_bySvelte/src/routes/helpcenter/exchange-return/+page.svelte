<style>
    body{
        margin-top: 100px;
        margin-left: 20px;
    }
    .section-heading {
       padding-bottom: 1.5rem;
       font-weight: bold;
       border-bottom: 1px solid #000;
   }
</style>
   
<body>
    
<h3 class= "section-heading">Exchange/Return policy</h3><br>
 
<div class="container">
    <h4>Condition</h4>
    <ul style="list-style-type:disc;">
        <li>Items can be returned or exchanged within 30 days of delivery.</li>
        <li>Items must be unused, in their original packaging, and in the same condition that you received them.</li>
        <li>Certain items, such as perishable goods, custom products, and personal care items, cannot be returned or exchanged.</li>
        <li>A receipt or proof of purchase is required for all returns and exchanges.</li>
    </ul>
 
    <h4>Exchange Policy</h4>
    <ul style="list-style-type:disc;">
        <li>To initiate an exchange, contact our customer service team through the app or via email at [OnceAgain@gmail.com].</li>
        <li>Provide your order number, details of the item you wish to exchange, and the reason for the exchange.</li>
        <li>Once your exchange request is approved, you will receive instructions on how to send back the item.</li>
        <li>If approved, we will process the exchange and send you the new item. Shipping times for the new item may vary depending on your location.</li>
    </ul>
 
    <h4>Return Policy</h4>
    <ul style="list-style-type:disc;">
        <li>To initiate a return, contact our customer service team through the app or via email at [OnceAgain@gmail.com].</li>
        <li>Provide your order number, details of the item you wish to return, and the reason for the return.</li>
        <li>Once your return request is approved, you will receive instructions on how to send back the item.</li>
    </ul>
</div>
 
<ul class="pager">
    <li class="previous"></li><a href="/helpcenter" class="btn" role="button">Back</a>
  </ul>
</body> 
