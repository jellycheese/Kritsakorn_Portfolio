<style>
    body{
        margin-top: 100px;
        margin-left: 20px;
    }
    .section-heading {
       padding-bottom: 1.5rem;
       font-weight: bold;
       border-bottom: 1px solid #000;
   }
</style>
 
<body>
    
<h3 class="section-heading">Available Payment Methods</h3><br>
 
<div class="container">
    <h4>We offer multiple payment methods.</h4>
        <li>Mobile Banking</li>
        <li>Credit Card</li>
        <li>Cash on Delivery</li>
        <br>
    <h4>How to choose a payment method:</h4>
    <ol>
        <li>Choose the product and press “Add to Cart”</li>
        <li>Press “Go to payment”</li>
        <li>Fill in the shipping address</li>
        <li>Choose the delivery option </li>
        <li>Press “ยืนยันการชำระเงิน”</li>
      </ol>
</div>
 
<ul class="pager">
    <li class="previous"></li><a href="/helpcenter" class="btn" role="button">Back</a>
</ul>
</body>
